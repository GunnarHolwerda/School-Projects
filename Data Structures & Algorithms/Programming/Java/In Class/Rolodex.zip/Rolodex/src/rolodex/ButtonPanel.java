/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rolodex;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author Brendan
 */
public class ButtonPanel extends JPanel {

    private JButton clearButton, enterButton, searchButton;

    public ButtonPanel() {
        setLayout(new FlowLayout());
        clearButton = new JButton("Clear");
        clearButton.addActionListener(new ClearPressed());
        add(clearButton);
        enterButton = new JButton("Enter");
        enterButton.addActionListener(new EnterPressed());
        add(enterButton);
        searchButton = new JButton("Search");
        searchButton.addActionListener(new SearchPressed());
        add(searchButton);

    }

    // Inner Class
    /**
     * The action listener for the button.
     */
    private class ClearPressed
            implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            Rolodex.contactPanel.clearFields();
        }
    }

    private class EnterPressed
            implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            System.out.println("Enter button was pressed.");
            Contact newContact = new Contact(Rolodex.contactPanel.firstNameField.getText(),
                    Rolodex.contactPanel.lastNameField.getText(),
                    Integer.parseInt(Rolodex.contactPanel.phoneField.getText()),
                    Rolodex.contactPanel.emailField.getText());
            Rolodex.myContacts[Rolodex.numContacts] = newContact;
            Rolodex.numContacts++;

            Rolodex.printContacts();

            Rolodex.contactPanel.clearFields();
        }
    }

    private class SearchPressed
            implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            System.out.println("Matchs found:");
            for (int i = 0; i < Rolodex.numContacts; i++) {
                Contact curContact = Rolodex.myContacts[i];
                if (curContact.match(Rolodex.contactPanel.firstNameField.getText(),
                        Rolodex.contactPanel.lastNameField.getText(),
                        Rolodex.contactPanel.phoneField.getText(),
                        Rolodex.contactPanel.emailField.getText())) {
                    // print it out
                    curContact.print();
                }
            }
            Rolodex.contactPanel.clearFields();
        }
    }
}
